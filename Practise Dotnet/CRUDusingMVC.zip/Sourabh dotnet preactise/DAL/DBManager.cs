namespace DAL;
using MySql.Data.MySqlClient;
using BOL;
using System.Collections.Generic;

public class DBManager
{
    public static string conString = @"server=192.168.10.150;port=3306;user=dac=6;password=welcome;database=dac6";
    public static List<User> GetAllUlist()
    {
        List<User> allUser = new List<User>();
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        string query = "select * from User";
        try
        {
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = query;
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int id = int.Parse(reader["id"].ToString());
                string un = reader["Username"].ToString();
                string pass = reader["Password"].ToString();

                User u = new User
                {
                    Id = id,
                    Username = un,
                    Password = pass
                };
                allUser.Add(u);
            }
        }
                     catch (Exception ee)
        {
            Console.WriteLine(ee.Message);
        }
        finally
        {
            con.Close();
        }

        return allUser;
    }
}
