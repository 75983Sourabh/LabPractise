namespace BOL;

public class Registration{
    public string fullname{get;set;}
    public string emailid{get;set;}
    public string password{get;set;}
    public string mobile{get;set;}

}