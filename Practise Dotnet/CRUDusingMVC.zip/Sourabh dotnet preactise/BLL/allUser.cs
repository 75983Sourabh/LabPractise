namespace BLL;
using BOL;
using DAL;
using System.Collections.Generic;

public class allUser{
    public List<User>GetAllUlist(){

    List<User>allUser=new List<User>();
    allUser=DBManager.GetAllUlist();
    return allUser;
    }
}
